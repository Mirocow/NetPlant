<?php

return array(
	'components' => array(
		'RSentryException' => array(
				'dsn'=> 'http://4824ccf7a6d1436298ed56ed425d73da:5dd81a24f4a341a3a40dda4d0050edc3@hydra.uptimehost.ru:9000/3',
			),
		'log' => array(
				'routes'=>array(
						'sentry'=>array(
		                    'dsn'=> 'http://4824ccf7a6d1436298ed56ed425d73da:5dd81a24f4a341a3a40dda4d0050edc3@hydra.uptimehost.ru:9000/3',
		                ),  
		                //'weblog'=>array('class'=>'CWebLogRoute', 'enabled'=>true)
		                'pqp' =>array(
			                'class' => 'application.extensions.pqp.PQPLogRoute',
			                'categories' => 'application.*, exception.*, system.*',
			                'levels'=>'error, warning, info',
			                'enabled'=>true,
			            ),
					),
				),
		),

);
