<?php

return array(


	'theme' => 'classic',
);
