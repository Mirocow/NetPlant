<?php
return array(
		'components' => array(
	        'db'=>array(
				'connectionString' => 'mysql:host=localhost;dbname=netplant',
				'emulatePrepare' => true,
				'username' => 'netplant',
				'password' => 'YOURPASSWORD',
				'charset' => 'utf8',
				'schemaCachingDuration' => 86400,
				'enableProfiling' => false,//true,
				'enableParamLogging' => false,//true,
				'tablePrefix'=>'',
			),
			
	    )
	);
